import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Sunrise, Music, BookOpen, Coffee, Star } from "lucide-react";

interface Recommendation {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: any;
  moodRange: number[];
}

const recommendations: Recommendation[] = [
  {
    id: "meditation",
    title: "5-Minute Meditation",
    description: "Try a quick breathing exercise to center yourself",
    category: "Mindfulness",
    icon: Heart,
    moodRange: [1, 3],
  },
  {
    id: "walk",
    title: "Nature Walk",
    description: "Take a gentle walk outside to boost your mood",
    category: "Movement",
    icon: Sunrise,
    moodRange: [1, 4],
  },
  {
    id: "music",
    title: "Uplifting Playlist",
    description: "Listen to your favorite songs to lift your spirits",
    category: "Entertainment",
    icon: Music,
    moodRange: [1, 3],
  },
  {
    id: "journal",
    title: "Gratitude Journal",
    description: "Write down three things you're grateful for today",
    category: "Reflection",
    icon: BookOpen,
    moodRange: [1, 5],
  },
  {
    id: "tea",
    title: "Mindful Tea Break",
    description: "Brew your favorite tea and enjoy it mindfully",
    category: "Self-care",
    icon: Coffee,
    moodRange: [2, 4],
  },
  {
    id: "celebrate",
    title: "Celebrate Today",
    description: "Acknowledge your positive mood and share it with someone",
    category: "Connection",
    icon: Star,
    moodRange: [4, 5],
  },
];

interface WellnessRecommendationsProps {
  currentMood?: number;
}

export function WellnessRecommendations({ currentMood }: WellnessRecommendationsProps) {
  const getRelevantRecommendations = () => {
    if (!currentMood) return recommendations.slice(0, 3);
    
    return recommendations
      .filter(rec => currentMood >= rec.moodRange[0] && currentMood <= rec.moodRange[1])
      .slice(0, 3);
  };

  const relevantRecs = getRelevantRecommendations();

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "Mindfulness": "bg-wellness-serenity text-white",
      "Movement": "bg-wellness-nature text-white",
      "Entertainment": "bg-wellness-calm text-white",
      "Reflection": "bg-accent text-accent-foreground",
      "Self-care": "bg-secondary text-secondary-foreground",
      "Connection": "bg-primary text-primary-foreground",
    };
    return colors[category] || "bg-muted text-muted-foreground";
  };

  return (
    <Card className="shadow-card border-0">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-semibold flex items-center gap-2">
          <Heart className="text-wellness-serenity" size={24} />
          Wellness Recommendations
          {currentMood && (
            <span className="ml-auto text-sm text-muted-foreground">
              Based on your current mood
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {relevantRecs.map((rec) => {
          const Icon = rec.icon;
          return (
            <div
              key={rec.id}
              className="p-4 rounded-xl border border-border bg-gradient-to-r from-card to-muted/20 hover:shadow-card transition-all duration-300 cursor-pointer group"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-gradient-primary">
                  <Icon className="text-white" size={20} />
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-foreground group-hover:text-wellness-calm transition-colors">
                      {rec.title}
                    </h4>
                    <Badge className={getCategoryColor(rec.category)}>
                      {rec.category}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {rec.description}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}