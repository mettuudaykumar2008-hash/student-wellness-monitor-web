import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, Area, AreaChart } from "recharts";
import { TrendingUp } from "lucide-react";

interface MoodData {
  date: string;
  mood: number;
  emotion: string;
}

interface MoodChartProps {
  data: MoodData[];
}

export function MoodChart({ data }: MoodChartProps) {
  const formattedData = data.map(entry => ({
    ...entry,
    displayDate: new Date(entry.date).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }),
  }));

  const averageMood = data.length > 0 
    ? (data.reduce((sum, entry) => sum + entry.mood, 0) / data.length).toFixed(1)
    : 0;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-card">
          <p className="text-sm font-medium">{label}</p>
          <p className="text-sm text-wellness-calm">
            Mood: {payload[0].value}/5 ({payload[0].payload.emotion})
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="shadow-card border-0">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-semibold flex items-center gap-2">
          <TrendingUp className="text-wellness-calm" size={24} />
          Mood Trends
          {data.length > 0 && (
            <span className="ml-auto text-sm bg-gradient-primary text-white px-3 py-1 rounded-full">
              Avg: {averageMood}/5
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <TrendingUp size={48} className="mx-auto mb-4 opacity-50" />
            <p>Start tracking your mood to see trends here</p>
          </div>
        ) : (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={formattedData}>
                <defs>
                  <linearGradient id="moodGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--wellness-calm))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--wellness-calm))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="displayDate" 
                  axisLine={false}
                  tickLine={false}
                  className="text-xs text-muted-foreground"
                />
                <YAxis 
                  domain={[1, 5]} 
                  axisLine={false}
                  tickLine={false}
                  className="text-xs text-muted-foreground"
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="mood"
                  stroke="hsl(var(--wellness-calm))"
                  strokeWidth={3}
                  fill="url(#moodGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}