import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MoodTracker } from "./MoodTracker";
import { MoodChart } from "./MoodChart";
import { WellnessRecommendations } from "./WellnessRecommendations";
import { Calendar, TrendingUp, Smile, Brain } from "lucide-react";

interface MoodEntry {
  id: string;
  mood: number;
  emotion: string;
  date: string;
  note?: string;
}

export function Dashboard() {
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>([]);
  const [currentStreak, setCurrentStreak] = useState(0);

  useEffect(() => {
    // Load mood entries from localStorage
    const saved = localStorage.getItem("wellnessMoodEntries");
    if (saved) {
      setMoodEntries(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    // Save mood entries to localStorage
    localStorage.setItem("wellnessMoodEntries", JSON.stringify(moodEntries));
    
    // Calculate streak
    const today = new Date().toDateString();
    const sortedEntries = [...moodEntries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    let streak = 0;
    let currentDate = new Date();
    
    for (const entry of sortedEntries) {
      const entryDate = new Date(entry.date);
      if (entryDate.toDateString() === currentDate.toDateString()) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }
    
    setCurrentStreak(streak);
  }, [moodEntries]);

  const handleMoodSubmit = (newEntry: MoodEntry) => {
    setMoodEntries(prev => [newEntry, ...prev]);
  };

  const todaysMood = moodEntries.find(entry => 
    new Date(entry.date).toDateString() === new Date().toDateString()
  );

  const averageMood = moodEntries.length > 0 
    ? (moodEntries.reduce((sum, entry) => sum + entry.mood, 0) / moodEntries.length).toFixed(1)
    : 0;

  const chartData = moodEntries
    .slice(0, 14)
    .reverse()
    .map(entry => ({
      date: entry.date,
      mood: entry.mood,
      emotion: entry.emotion,
    }));

  return (
    <div className="min-h-screen bg-gradient-calm p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2 py-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Wellness Tracker
          </h1>
          <p className="text-lg text-muted-foreground">
            Your daily companion for mental health and wellbeing
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="shadow-card border-0 bg-gradient-primary text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Calendar size={16} />
                Current Streak
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{currentStreak} days</div>
            </CardContent>
          </Card>

          <Card className="shadow-card border-0 bg-gradient-secondary text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp size={16} />
                Average Mood
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{averageMood}/5</div>
            </CardContent>
          </Card>

          <Card className="shadow-card border-0 bg-wellness-nature text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Brain size={16} />
                Total Entries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{moodEntries.length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column */}
          <div className="space-y-6">
            <MoodTracker onMoodSubmit={handleMoodSubmit} />
            
            {todaysMood && (
              <Card className="shadow-card border-0 bg-gradient-secondary text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Smile size={20} />
                    Today's Mood
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-xl font-semibold">{todaysMood.emotion}</div>
                  <div className="text-sm opacity-90">{todaysMood.mood}/5</div>
                  {todaysMood.note && (
                    <p className="text-sm mt-2 opacity-90">"{todaysMood.note}"</p>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <WellnessRecommendations currentMood={todaysMood?.mood} />
          </div>
        </div>

        {/* Chart */}
        <MoodChart data={chartData} />
      </div>
    </div>
  );
}