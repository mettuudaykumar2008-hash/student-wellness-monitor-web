import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Smile, Frown, Meh, Heart, Zap } from "lucide-react";

interface MoodEntry {
  id: string;
  mood: number;
  emotion: string;
  date: string;
  note?: string;
}

interface MoodTrackerProps {
  onMoodSubmit: (mood: MoodEntry) => void;
}

const moodOptions = [
  { value: 1, label: "Very Low", icon: Frown, color: "text-red-500", bg: "bg-red-50" },
  { value: 2, label: "Low", icon: Frown, color: "text-orange-500", bg: "bg-orange-50" },
  { value: 3, label: "Neutral", icon: Meh, color: "text-yellow-500", bg: "bg-yellow-50" },
  { value: 4, label: "Good", icon: Smile, color: "text-green-500", bg: "bg-green-50" },
  { value: 5, label: "Excellent", icon: Heart, color: "text-wellness-nature", bg: "bg-wellness-soft" },
];

export function MoodTracker({ onMoodSubmit }: MoodTrackerProps) {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [note, setNote] = useState("");

  const handleSubmit = () => {
    if (selectedMood) {
      const mood = moodOptions.find(m => m.value === selectedMood);
      const entry: MoodEntry = {
        id: Date.now().toString(),
        mood: selectedMood,
        emotion: mood?.label || "",
        date: new Date().toISOString(),
        note: note || undefined,
      };
      onMoodSubmit(entry);
      setSelectedMood(null);
      setNote("");
    }
  };

  return (
    <Card className="shadow-card border-0 bg-gradient-calm">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl font-semibold text-foreground flex items-center justify-center gap-2">
          <Zap className="text-wellness-calm" size={28} />
          How are you feeling today?
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-5 gap-3">
          {moodOptions.map((mood) => {
            const Icon = mood.icon;
            const isSelected = selectedMood === mood.value;
            return (
              <button
                key={mood.value}
                onClick={() => setSelectedMood(mood.value)}
                className={`p-4 rounded-2xl transition-all duration-300 transform hover:scale-105 border-2 ${
                  isSelected
                    ? `${mood.bg} border-wellness-calm shadow-soft`
                    : "bg-card border-border hover:border-wellness-calm hover:shadow-card"
                }`}
              >
                <Icon className={`mx-auto mb-2 ${mood.color}`} size={32} />
                <div className="text-xs font-medium text-center">{mood.label}</div>
              </button>
            );
          })}
        </div>

        <div className="space-y-3">
          <label className="text-sm font-medium text-muted-foreground">
            Add a note (optional)
          </label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="How was your day? What influenced your mood?"
            className="w-full p-3 rounded-xl border border-border bg-card resize-none min-h-[80px] focus:ring-2 focus:ring-wellness-calm focus:border-transparent transition-all"
          />
        </div>

        <Button
          onClick={handleSubmit}
          disabled={!selectedMood}
          className="w-full bg-gradient-primary text-white font-medium py-3 rounded-xl hover:shadow-soft transition-all duration-300 disabled:opacity-50"
        >
          Record Mood
        </Button>
      </CardContent>
    </Card>
  );
}